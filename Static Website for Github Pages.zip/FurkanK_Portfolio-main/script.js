document.querySelector("form").addEventListener("submit", e => {
  e.preventDefault();
  alert("Message sent successfully!");
});
